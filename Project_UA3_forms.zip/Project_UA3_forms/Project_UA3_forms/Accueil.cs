﻿using Project_UA3_forms.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms
{
    public partial class Accueil : Form
    {
        public Accueil()
        {
            InitializeComponent();
        }

        private void FermerPage()
        {
            this.Close();
        }

        private void buttonFermer_Click(object sender, EventArgs e)
        {
            FermerPage();
        }


        private void Accueil_Load(object sender, EventArgs e)
        {

        }

        private void Grade(object sender, EventArgs e)
        {
            using (Grade grd = new Grade())
            {
                grd.ShowDialog();
            }
        }

        private void Student(object sender, EventArgs e)
        {
            using (Student std = new Student())
            {
                std.ShowDialog();
            }
        }

        private void Course(object sender, EventArgs e)
        {
            using (Course course = new Course())
            {
                course.ShowDialog();
            }
        }
    }
}
