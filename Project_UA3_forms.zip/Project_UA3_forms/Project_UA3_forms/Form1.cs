﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms
{
    public partial class Projet_Final : Form
    {
        public Projet_Final()
        {
            InitializeComponent(); 
        }

       

        private void Projet_Final_Load(object sender, EventArgs e)
        {

        }   

       

        private void login_Click(object sender, EventArgs e)
        {
          
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (Accueil ac = new Accueil())
            {
                ac.ShowDialog();
            }
        }
    }
}
