﻿using System;
using System.Windows.Forms;

namespace Project_UA3_forms
{
    partial class Create_course
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.Titretb = new System.Windows.Forms.TextBox();
            this.prenom_etudiant = new System.Windows.Forms.Label();
            this.Codetb = new System.Windows.Forms.TextBox();
            this.nom_etudiant = new System.Windows.Forms.Label();
            this.Idcourstb = new System.Windows.Forms.TextBox();
            this.id_cours = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(637, 77);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(177, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = " CRÉER COURS";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 77);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(17, 456);
            this.panel3.TabIndex = 15;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(620, 77);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(17, 456);
            this.panel4.TabIndex = 16;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(17, 529);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(603, 4);
            this.panel5.TabIndex = 17;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(250, 388);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(201, 61);
            this.button2.TabIndex = 35;
            this.button2.Text = "SAUVEGARDER";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.SaveCourse);
            // 
            // Titretb
            // 
            this.Titretb.Location = new System.Drawing.Point(250, 272);
            this.Titretb.Name = "Titretb";
            this.Titretb.Size = new System.Drawing.Size(296, 22);
            this.Titretb.TabIndex = 32;
            // 
            // prenom_etudiant
            // 
            this.prenom_etudiant.AutoSize = true;
            this.prenom_etudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prenom_etudiant.Location = new System.Drawing.Point(45, 272);
            this.prenom_etudiant.Name = "prenom_etudiant";
            this.prenom_etudiant.Size = new System.Drawing.Size(47, 22);
            this.prenom_etudiant.TabIndex = 31;
            this.prenom_etudiant.Text = "Titre";
            // 
            // Codetb
            // 
            this.Codetb.Location = new System.Drawing.Point(250, 210);
            this.Codetb.Name = "Codetb";
            this.Codetb.Size = new System.Drawing.Size(296, 22);
            this.Codetb.TabIndex = 30;
            // 
            // nom_etudiant
            // 
            this.nom_etudiant.AutoSize = true;
            this.nom_etudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nom_etudiant.Location = new System.Drawing.Point(45, 210);
            this.nom_etudiant.Name = "nom_etudiant";
            this.nom_etudiant.Size = new System.Drawing.Size(53, 22);
            this.nom_etudiant.TabIndex = 29;
            this.nom_etudiant.Text = "Code";
            // 
            // Idcourstb
            // 
            this.Idcourstb.Location = new System.Drawing.Point(250, 154);
            this.Idcourstb.Name = "Idcourstb";
            this.Idcourstb.Size = new System.Drawing.Size(296, 22);
            this.Idcourstb.TabIndex = 28;
            // 
            // id_cours
            // 
            this.id_cours.AutoSize = true;
            this.id_cours.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id_cours.Location = new System.Drawing.Point(45, 154);
            this.id_cours.Name = "id_cours";
            this.id_cours.Size = new System.Drawing.Size(102, 22);
            this.id_cours.TabIndex = 27;
            this.id_cours.Text = "ID_COURS";
            this.id_cours.Click += new System.EventHandler(this.id_étudiant_Click);
            // 
            // Create_course
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 533);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Titretb);
            this.Controls.Add(this.prenom_etudiant);
            this.Controls.Add(this.Codetb);
            this.Controls.Add(this.nom_etudiant);
            this.Controls.Add(this.Idcourstb);
            this.Controls.Add(this.id_cours);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Name = "Create_course";
            this.Text = "Create_course";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void id_étudiant_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {
           
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox Titretb;
        private System.Windows.Forms.Label prenom_etudiant;
        private System.Windows.Forms.TextBox Codetb;
        private System.Windows.Forms.Label nom_etudiant;
        private System.Windows.Forms.TextBox Idcourstb;
        private System.Windows.Forms.Label id_cours;
    }
}