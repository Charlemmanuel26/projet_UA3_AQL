﻿namespace Project_UA3_forms.Create
{
    partial class Add_grade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tbNote1 = new System.Windows.Forms.TextBox();
            this.note1 = new System.Windows.Forms.Label();
            this.tbIdcours = new System.Windows.Forms.TextBox();
            this.nom_etudiant = new System.Windows.Forms.Label();
            this.tbIdetudiant = new System.Windows.Forms.TextBox();
            this.id_étudiant = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tbNote2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNote3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(17, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(671, 77);
            this.panel1.TabIndex = 27;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(194, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(242, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "AJOUTER NOTE";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(275, 464);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(201, 61);
            this.button2.TabIndex = 39;
            this.button2.Text = "SAUVEGARDER";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.AddGrade);
            // 
            // tbNote1
            // 
            this.tbNote1.Location = new System.Drawing.Point(264, 292);
            this.tbNote1.Name = "tbNote1";
            this.tbNote1.Size = new System.Drawing.Size(257, 22);
            this.tbNote1.TabIndex = 36;
            // 
            // note1
            // 
            this.note1.AutoSize = true;
            this.note1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.note1.Location = new System.Drawing.Point(59, 292);
            this.note1.Name = "note1";
            this.note1.Size = new System.Drawing.Size(63, 22);
            this.note1.TabIndex = 35;
            this.note1.Text = "Note 1";
            // 
            // tbIdcours
            // 
            this.tbIdcours.Location = new System.Drawing.Point(264, 230);
            this.tbIdcours.Name = "tbIdcours";
            this.tbIdcours.Size = new System.Drawing.Size(296, 22);
            this.tbIdcours.TabIndex = 34;
            this.tbIdcours.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // nom_etudiant
            // 
            this.nom_etudiant.AutoSize = true;
            this.nom_etudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nom_etudiant.Location = new System.Drawing.Point(59, 230);
            this.nom_etudiant.Name = "nom_etudiant";
            this.nom_etudiant.Size = new System.Drawing.Size(80, 22);
            this.nom_etudiant.TabIndex = 33;
            this.nom_etudiant.Text = "ID Cours";
            this.nom_etudiant.Click += new System.EventHandler(this.nom_etudiant_Click);
            // 
            // tbIdetudiant
            // 
            this.tbIdetudiant.Location = new System.Drawing.Point(264, 174);
            this.tbIdetudiant.Name = "tbIdetudiant";
            this.tbIdetudiant.Size = new System.Drawing.Size(296, 22);
            this.tbIdetudiant.TabIndex = 32;
            // 
            // id_étudiant
            // 
            this.id_étudiant.AutoSize = true;
            this.id_étudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id_étudiant.Location = new System.Drawing.Point(59, 174);
            this.id_étudiant.Name = "id_étudiant";
            this.id_étudiant.Size = new System.Drawing.Size(123, 22);
            this.id_étudiant.TabIndex = 31;
            this.id_étudiant.Text = "ID ÉTUDIANT";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(17, 691);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(671, 4);
            this.panel5.TabIndex = 30;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(17, 695);
            this.panel3.TabIndex = 29;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(688, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(17, 695);
            this.panel4.TabIndex = 28;
            // 
            // tbNote2
            // 
            this.tbNote2.Location = new System.Drawing.Point(264, 336);
            this.tbNote2.Name = "tbNote2";
            this.tbNote2.Size = new System.Drawing.Size(257, 22);
            this.tbNote2.TabIndex = 43;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(59, 334);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 22);
            this.label2.TabIndex = 42;
            this.label2.Text = "Note 2";
            // 
            // tbNote3
            // 
            this.tbNote3.Location = new System.Drawing.Point(264, 377);
            this.tbNote3.Name = "tbNote3";
            this.tbNote3.Size = new System.Drawing.Size(257, 22);
            this.tbNote3.TabIndex = 45;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 377);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 22);
            this.label3.TabIndex = 44;
            this.label3.Text = "Note 3";
            // 
            // Add_grade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 695);
            this.Controls.Add(this.tbNote3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbNote2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tbNote1);
            this.Controls.Add(this.note1);
            this.Controls.Add(this.tbIdcours);
            this.Controls.Add(this.nom_etudiant);
            this.Controls.Add(this.tbIdetudiant);
            this.Controls.Add(this.id_étudiant);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Name = "Add_grade";
            this.Text = "Add_grade";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tbNote1;
        private System.Windows.Forms.Label note1;
        private System.Windows.Forms.TextBox tbIdcours;
        private System.Windows.Forms.Label nom_etudiant;
        private System.Windows.Forms.TextBox tbIdetudiant;
        private System.Windows.Forms.Label id_étudiant;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.TextBox tbNote2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNote3;
        private System.Windows.Forms.Label label3;
    }
}