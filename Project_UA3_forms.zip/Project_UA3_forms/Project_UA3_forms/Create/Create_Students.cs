﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms
{
    public partial class Create_Student : Form
    {
        public event EventHandler StudentAdded;

        public Create_Student()
        {
            InitializeComponent();
        }

        private void SaveStudent(object sender, EventArgs e)
        {
            StreamWriter sw = new StreamWriter(Application.StartupPath + "\\Étudiants\\" + Idétudianttb.Text + " " + Nomtb.Text + " " + Prenomtb.Text + ".txt");

            sw.Write(Idétudianttb.Text + " , ");
            sw.Write(Nomtb.Text + " , ");
            sw.WriteLine(Prenomtb.Text);
            sw.Close();

            OnStudentAdded();
        }

        protected virtual void OnStudentAdded()
        {
            StudentAdded?.Invoke(this, EventArgs.Empty);
        }
    }
}




