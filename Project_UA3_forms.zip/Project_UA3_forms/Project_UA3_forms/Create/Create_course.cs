﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms
{
    public partial class Create_course : Form
    {

        public event EventHandler CourseAdded;
        public Create_course()
        {
            InitializeComponent();
        }

     

        private void SaveCourse(object sender, EventArgs e)
        {
            StreamWriter create_course = new StreamWriter(Application.StartupPath + "\\Cours\\" + Idcourstb.Text + " " + Codetb.Text + " " + Titretb.Text + ".txt");

            create_course.Write(Idcourstb.Text + " , ");
            create_course.Write(Codetb.Text + " , ");
            create_course.WriteLine(Titretb.Text);
            create_course.Close();

            OnCourseAdded();
        }
        protected virtual void OnCourseAdded()
        {
            CourseAdded?.Invoke(this, EventArgs.Empty);
        }

    }
}
