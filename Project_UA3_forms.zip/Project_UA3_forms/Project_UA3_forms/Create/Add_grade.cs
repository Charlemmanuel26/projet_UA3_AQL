﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms.Create
{
    public partial class Add_grade : Form
    {
        public event EventHandler GradeAdded;
        public Add_grade()
        {
            InitializeComponent();
        }

        private void nom_etudiant_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddGrade(object sender, EventArgs e)
        {
            StreamWriter addg = new StreamWriter(Application.StartupPath + "\\Notes\\" + tbIdetudiant.Text + " " + tbIdcours.Text + " " + tbNote1.Text + " " + tbNote2.Text+ " " +tbNote3.Text+ ".txt");

            addg.Write(tbIdetudiant.Text + " , ");
            addg.Write(tbIdcours.Text + " , ");
            addg.WriteLine(tbNote1.Text+ " , ");
            addg.WriteLine(tbNote2.Text + " , ");
            addg.WriteLine(tbNote3.Text);
            addg.Close();

            OnGradeAdded();
        }

        protected virtual void OnGradeAdded()
        {
            GradeAdded?.Invoke(this, EventArgs.Empty);
        }
    }
}
