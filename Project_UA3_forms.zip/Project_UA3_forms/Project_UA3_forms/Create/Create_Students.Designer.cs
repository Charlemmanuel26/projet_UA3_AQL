﻿using System;

namespace Project_UA3_forms
{
    partial class Create_Student
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.id_étudiant = new System.Windows.Forms.Label();
            this.Idétudianttb = new System.Windows.Forms.TextBox();
            this.Nomtb = new System.Windows.Forms.TextBox();
            this.nom_etudiant = new System.Windows.Forms.Label();
            this.Prenomtb = new System.Windows.Forms.TextBox();
            this.prenom_etudiant = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(694, 77);
            this.panel1.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(206, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(280, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = " CRÉER ÉTUDIANT";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(677, 77);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(17, 631);
            this.panel4.TabIndex = 13;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 77);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(17, 631);
            this.panel3.TabIndex = 14;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(17, 704);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(660, 4);
            this.panel5.TabIndex = 15;
            // 
            // id_étudiant
            // 
            this.id_étudiant.AutoSize = true;
            this.id_étudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id_étudiant.Location = new System.Drawing.Point(59, 174);
            this.id_étudiant.Name = "id_étudiant";
            this.id_étudiant.Size = new System.Drawing.Size(123, 22);
            this.id_étudiant.TabIndex = 16;
            this.id_étudiant.Text = "ID ÉTUDIANT";
            this.id_étudiant.Click += new System.EventHandler(this.id_étudiant_Click);
            // 
            // Idétudianttb
            // 
            this.Idétudianttb.Location = new System.Drawing.Point(264, 174);
            this.Idétudianttb.Name = "Idétudianttb";
            this.Idétudianttb.Size = new System.Drawing.Size(296, 22);
            this.Idétudianttb.TabIndex = 17;
            this.Idétudianttb.TextChanged += new System.EventHandler(this.Idétudianttb_TextChanged);
            // 
            // Nomtb
            // 
            this.Nomtb.Location = new System.Drawing.Point(264, 230);
            this.Nomtb.Name = "Nomtb";
            this.Nomtb.Size = new System.Drawing.Size(296, 22);
            this.Nomtb.TabIndex = 19;
            // 
            // nom_etudiant
            // 
            this.nom_etudiant.AutoSize = true;
            this.nom_etudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nom_etudiant.Location = new System.Drawing.Point(59, 230);
            this.nom_etudiant.Name = "nom_etudiant";
            this.nom_etudiant.Size = new System.Drawing.Size(47, 22);
            this.nom_etudiant.TabIndex = 18;
            this.nom_etudiant.Text = "Nom";
            this.nom_etudiant.Click += new System.EventHandler(this.nom_etudiant_Click);
            // 
            // Prenomtb
            // 
            this.Prenomtb.Location = new System.Drawing.Point(264, 292);
            this.Prenomtb.Name = "Prenomtb";
            this.Prenomtb.Size = new System.Drawing.Size(296, 22);
            this.Prenomtb.TabIndex = 21;
            // 
            // prenom_etudiant
            // 
            this.prenom_etudiant.AutoSize = true;
            this.prenom_etudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prenom_etudiant.Location = new System.Drawing.Point(59, 292);
            this.prenom_etudiant.Name = "prenom_etudiant";
            this.prenom_etudiant.Size = new System.Drawing.Size(72, 22);
            this.prenom_etudiant.TabIndex = 20;
            this.prenom_etudiant.Text = "Prénom";
            this.prenom_etudiant.Click += new System.EventHandler(this.prenom_etudiant_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(40, 424);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(201, 61);
            this.button2.TabIndex = 24;
            this.button2.Text = "SAUVEGARDER";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.SaveStudent);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(264, 424);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(201, 61);
            this.button1.TabIndex = 25;
            this.button1.Text = "REINITIALISER";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(504, 424);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 61);
            this.button3.TabIndex = 26;
            this.button3.Text = "FERMER";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // Create_Students
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 708);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Prenomtb);
            this.Controls.Add(this.prenom_etudiant);
            this.Controls.Add(this.Nomtb);
            this.Controls.Add(this.nom_etudiant);
            this.Controls.Add(this.Idétudianttb);
            this.Controls.Add(this.id_étudiant);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Name = "Create_Students";
            this.Text = "Create_Students";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void prenom_etudiant_Click(object sender, EventArgs e)
        {

        }

        private void nom_etudiant_Click(object sender, EventArgs e)
        {

        }

        private void Idétudianttb_TextChanged(object sender, EventArgs e)
        {


        }

        private void id_étudiant_Click(object sender, EventArgs e)
        {
            ;
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.TextBox Idétudianttb;
        private System.Windows.Forms.TextBox Nomtb;
        private System.Windows.Forms.Label nom_etudiant;
        private System.Windows.Forms.TextBox Prenomtb;
        private System.Windows.Forms.Label prenom_etudiant;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button3;
        public System.Windows.Forms.Label id_étudiant;
    }
}