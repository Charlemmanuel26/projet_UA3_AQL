﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms.Update
{
    public partial class Update_course : Form
    {
        public Update_course()
        {
            InitializeComponent();
        }

        private void Rechercher_cours(object sender, EventArgs e)
        {
            string idToSearch = searchCours.Text.Trim();
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\cours";

            string[] files = Directory.GetFiles(directoryPath, "*.txt");

            foreach (string file in files)
            {
                string[] parts = File.ReadAllText(file).Split(',');

                if (parts.Length >= 3 && parts[0].Trim() == idToSearch)
                {
                    // Afficher les informations dans les TextBox
                    textBox2Code.Text = parts[1].Trim();
                    textBox3Titre.Text = parts[2].Trim();


                }
            }
        }


        private void save_update(object sender, EventArgs e)
        {
            string idToUpdate = searchCours.Text.Trim();
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Cours";

            string[] files = Directory.GetFiles(directoryPath, "*.txt");

            foreach (string file in files)
            {
                string[] parts = File.ReadAllText(file).Split(',');

                if (parts.Length >= 3 && parts[0].Trim() == idToUpdate)
                {
                    // Mettre à jour les informations
                    parts[1] = textBox2Code.Text.Trim();
                    parts[2] = textBox3Titre.Text.Trim();

                    // Écrire les nouvelles informations dans le fichier
                    File.WriteAllText(file, string.Join(",", parts));

                    MessageBox.Show("Les informations du cours ont été mises à jour avec succès.");

                    // Rafraîchir la DataGridView
                    Course courseForm = Application.OpenForms.OfType<Course>().FirstOrDefault();
                    if (courseForm != null)
                    {
                        courseForm.RefreshDataGridView();
                    }

                    break; // Sortir de la boucle car le cours a été trouvé et mis à jour
                }
            }
        }

        private void SupprimerCours(object sender, EventArgs e)
        {
            string idToDelete = searchCours.Text.Trim();
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Cours";

            string[] files = Directory.GetFiles(directoryPath, "*.txt");

            foreach (string file in files)
            {
                string[] parts = File.ReadAllText(file).Split(',');

                if (parts.Length >= 3 && parts[0].Trim() == idToDelete)
                {
                    // Supprimer le fichier correspondant au cours
                    File.Delete(file);

                    MessageBox.Show("Le cours a été supprimé avec succès.");

                    // Rafraîchir la DataGridView
                    Course courseForm = Application.OpenForms.OfType<Course>().FirstOrDefault();
                    if (courseForm != null)
                    {
                        courseForm.RefreshDataGridView();
                    }

                    break;
                }
            }
        }
    }
}
