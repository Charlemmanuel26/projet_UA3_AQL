﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms
{
    public partial class Update_student : Form
    {
        public Update_student()
        {
            InitializeComponent();
        }

        private void Update_student_Load(object sender, EventArgs e)
        {

        }

        private void Rechercher_Id(object sender, EventArgs e)
        {
            string idToSearch = textBoxIdToSearch.Text.Trim();
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Étudiants";

            string[] files = Directory.GetFiles(directoryPath, "*.txt");

            foreach (string file in files)
            {
                string[] parts = File.ReadAllText(file).Split(',');

                if (parts.Length >= 3 && parts[0].Trim() == idToSearch)
                {
                    // Afficher les informations dans les TextBox
                    textBox2Nom.Text = parts[1].Trim();
                    textBox3Prenom.Text = parts[2].Trim();


                }
            }
        }

        private void save_update(object sender, EventArgs e)
        {
            string idToUpdate = textBoxIdToSearch.Text.Trim();
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Étudiants";

            string[] files = Directory.GetFiles(directoryPath, "*.txt");

            foreach (string file in files)
            {
                string[] parts = File.ReadAllText(file).Split(',');

                if (parts.Length >= 3 && parts[0].Trim() == idToUpdate)
                {
                    // Mettre à jour les informations
                    parts[1] = textBox2Nom.Text.Trim();
                    parts[2] = textBox3Prenom.Text.Trim();

                    // Écrire les nouvelles informations dans le fichier
                    File.WriteAllText(file, string.Join(",", parts));

                    MessageBox.Show("Les informations de l'étudiant ont été mises à jour avec succès.");
                    Student studentForm = Application.OpenForms.OfType<Student>().FirstOrDefault();
                    if (studentForm != null)
                    {
                        studentForm.RefreshDataGridView();
                    }

                    break;
                }
            }
        }

        private void SupprimerEtudiant(object sender, EventArgs e)
        {
            string idToDelete = textBoxIdToSearch.Text.Trim();
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Étudiants";

            string[] files = Directory.GetFiles(directoryPath, "*.txt");

            foreach (string file in files)
            {
                string[] parts = File.ReadAllText(file).Split(',');

                if (parts.Length >= 3 && parts[0].Trim() == idToDelete)
                {
                    // Supprimer le fichier correspondant à l'étudiant
                    File.Delete(file);

                    MessageBox.Show("L'étudiant a été supprimé avec succès.");

                    // Rafraîchir la DataGridView
                    Student studentForm = Application.OpenForms.OfType<Student>().FirstOrDefault();
                    if (studentForm != null)
                    {
                        studentForm.RefreshDataGridView();
                    }

                    break;
                }
            }
        }
    }
}