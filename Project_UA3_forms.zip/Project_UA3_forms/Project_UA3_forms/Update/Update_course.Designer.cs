﻿namespace Project_UA3_forms.Update
{
    partial class Update_course
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox3Titre = new System.Windows.Forms.TextBox();
            this.prenom_etudiant = new System.Windows.Forms.Label();
            this.textBox2Code = new System.Windows.Forms.TextBox();
            this.nom_etudiant = new System.Windows.Forms.Label();
            this.searchCours = new System.Windows.Forms.TextBox();
            this.id_étudiant = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(17, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(667, 77);
            this.panel1.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(192, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(271, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "MODIFIER COURS";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(435, 402);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(201, 61);
            this.button1.TabIndex = 49;
            this.button1.Text = "SUPPRIMER";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.SupprimerCours);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(451, 154);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(185, 33);
            this.button2.TabIndex = 48;
            this.button2.Text = "Rechercher";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Rechercher_cours);
            // 
            // textBox3Titre
            // 
            this.textBox3Titre.Location = new System.Drawing.Point(250, 272);
            this.textBox3Titre.Name = "textBox3Titre";
            this.textBox3Titre.Size = new System.Drawing.Size(296, 22);
            this.textBox3Titre.TabIndex = 47;
            // 
            // prenom_etudiant
            // 
            this.prenom_etudiant.AutoSize = true;
            this.prenom_etudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prenom_etudiant.Location = new System.Drawing.Point(45, 272);
            this.prenom_etudiant.Name = "prenom_etudiant";
            this.prenom_etudiant.Size = new System.Drawing.Size(47, 22);
            this.prenom_etudiant.TabIndex = 46;
            this.prenom_etudiant.Text = "Titre";
            // 
            // textBox2Code
            // 
            this.textBox2Code.Location = new System.Drawing.Point(250, 210);
            this.textBox2Code.Name = "textBox2Code";
            this.textBox2Code.Size = new System.Drawing.Size(296, 22);
            this.textBox2Code.TabIndex = 45;
            // 
            // nom_etudiant
            // 
            this.nom_etudiant.AutoSize = true;
            this.nom_etudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nom_etudiant.Location = new System.Drawing.Point(45, 210);
            this.nom_etudiant.Name = "nom_etudiant";
            this.nom_etudiant.Size = new System.Drawing.Size(53, 22);
            this.nom_etudiant.TabIndex = 44;
            this.nom_etudiant.Text = "Code";
            // 
            // searchCours
            // 
            this.searchCours.Location = new System.Drawing.Point(250, 154);
            this.searchCours.Name = "searchCours";
            this.searchCours.Size = new System.Drawing.Size(172, 22);
            this.searchCours.TabIndex = 43;
            // 
            // id_étudiant
            // 
            this.id_étudiant.AutoSize = true;
            this.id_étudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id_étudiant.Location = new System.Drawing.Point(45, 154);
            this.id_étudiant.Name = "id_étudiant";
            this.id_étudiant.Size = new System.Drawing.Size(97, 22);
            this.id_étudiant.TabIndex = 42;
            this.id_étudiant.Text = "ID COURS";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(17, 650);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(667, 4);
            this.panel5.TabIndex = 41;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(684, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(17, 654);
            this.panel4.TabIndex = 40;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(17, 654);
            this.panel3.TabIndex = 39;
            // 
            // button
            // 
            this.button.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button.Location = new System.Drawing.Point(99, 402);
            this.button.Name = "button";
            this.button.Size = new System.Drawing.Size(207, 61);
            this.button.TabIndex = 51;
            this.button.Text = "SAUVEGARDER";
            this.button.UseVisualStyleBackColor = false;
            this.button.Click += new System.EventHandler(this.save_update);
            // 
            // Update_course
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(701, 654);
            this.Controls.Add(this.button);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox3Titre);
            this.Controls.Add(this.prenom_etudiant);
            this.Controls.Add(this.textBox2Code);
            this.Controls.Add(this.nom_etudiant);
            this.Controls.Add(this.searchCours);
            this.Controls.Add(this.id_étudiant);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Name = "Update_course";
            this.Text = "Update_course";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox3Titre;
        private System.Windows.Forms.Label prenom_etudiant;
        private System.Windows.Forms.TextBox textBox2Code;
        private System.Windows.Forms.Label nom_etudiant;
        private System.Windows.Forms.TextBox searchCours;
        private System.Windows.Forms.Label id_étudiant;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button;
    }
}