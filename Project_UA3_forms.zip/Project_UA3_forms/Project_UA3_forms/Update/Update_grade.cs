﻿using Project_UA3_forms.Classes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms.Update
{
    public partial class Update_grade : Form
    {
        public Update_grade()
        {
            InitializeComponent();
        }

        private void save_update(object sender, EventArgs e)
        {

            string idToUpdate = tbidetudiant.Text.Trim();
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Notes";

            string[] files = Directory.GetFiles(directoryPath, "*.txt");

            foreach (string file in files)
            {
                string[] parts = File.ReadAllText(file).Split(',');

                if (parts.Length >= 3 && parts[0].Trim() == idToUpdate)
                {
                    // Mettre à jour les informations

                    parts[1] = tbidcours.Text.Trim();
                    parts[2] = tbNote1.Text.Trim();
                    parts[3] = tbNote2.Text.Trim();
                    parts[4] = tbNote3.Text.Trim();

                    // Écrire les nouvelles informations dans le fichier
                    File.WriteAllText(file, string.Join(",", parts));

                    MessageBox.Show("Les notes ont été mises à jour avec succès.");

                    // Rafraîchir la DataGridView
                    Grade gradeForm = Application.OpenForms.OfType<Grade>().FirstOrDefault();
                    if (gradeForm != null)
                    {
                        gradeForm.RefreshDataGridView();
                    }

                    break; // Sortir de la boucle car le cours a été trouvé et mis à jour
                }
            }
        }



        private void searchgrade(object sender, EventArgs e)
        {
            string idToSearch = tbidetudiant.Text.Trim();
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Notes";

            string[] files = Directory.GetFiles(directoryPath, "*.txt");

            foreach (string file in files)
            {
                string[] parts = File.ReadAllText(file).Split(',');

                if (parts.Length >= 3 && parts[0].Trim() == idToSearch)
                {
                    // Afficher les informations dans les TextBox
                    tbidcours.Text = parts[1].Trim();
                    tbNote1.Text = parts[2].Trim();
                    tbNote2.Text = parts[3].Trim();
                    tbNote3.Text = parts[4].Trim();


                }
            }
        }
    }
}



       
