﻿namespace Project_UA3_forms.Update
{
    partial class Update_grade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tbidcours = new System.Windows.Forms.TextBox();
            this.nom_etudiant = new System.Windows.Forms.Label();
            this.tbidetudiant = new System.Windows.Forms.TextBox();
            this.id_étudiant = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.tbNote3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbNote2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbNote1 = new System.Windows.Forms.TextBox();
            this.note1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(17, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(710, 77);
            this.panel1.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(214, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(247, 32);
            this.label1.TabIndex = 1;
            this.label1.Text = "MODIFIER NOTE";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(253, 431);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(201, 61);
            this.button2.TabIndex = 52;
            this.button2.Text = "SAUVEGARDER";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.save_update);
            // 
            // tbidcours
            // 
            this.tbidcours.Location = new System.Drawing.Point(237, 232);
            this.tbidcours.Name = "tbidcours";
            this.tbidcours.Size = new System.Drawing.Size(296, 22);
            this.tbidcours.TabIndex = 49;
            // 
            // nom_etudiant
            // 
            this.nom_etudiant.AutoSize = true;
            this.nom_etudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nom_etudiant.Location = new System.Drawing.Point(59, 230);
            this.nom_etudiant.Name = "nom_etudiant";
            this.nom_etudiant.Size = new System.Drawing.Size(80, 22);
            this.nom_etudiant.TabIndex = 48;
            this.nom_etudiant.Text = "ID Cours";
            // 
            // tbidetudiant
            // 
            this.tbidetudiant.Location = new System.Drawing.Point(237, 174);
            this.tbidetudiant.Name = "tbidetudiant";
            this.tbidetudiant.Size = new System.Drawing.Size(205, 22);
            this.tbidetudiant.TabIndex = 47;
            // 
            // id_étudiant
            // 
            this.id_étudiant.AutoSize = true;
            this.id_étudiant.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.id_étudiant.Location = new System.Drawing.Point(59, 174);
            this.id_étudiant.Name = "id_étudiant";
            this.id_étudiant.Size = new System.Drawing.Size(123, 22);
            this.id_étudiant.TabIndex = 46;
            this.id_étudiant.Text = "ID ÉTUDIANT";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel5.Location = new System.Drawing.Point(17, 592);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(710, 4);
            this.panel5.TabIndex = 45;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(17, 596);
            this.panel3.TabIndex = 44;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.panel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel4.Location = new System.Drawing.Point(727, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(17, 596);
            this.panel4.TabIndex = 43;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Schoolbook", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(490, 164);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(151, 42);
            this.button4.TabIndex = 55;
            this.button4.Text = "Rechercher";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.searchgrade);
            // 
            // tbNote3
            // 
            this.tbNote3.Location = new System.Drawing.Point(237, 341);
            this.tbNote3.Name = "tbNote3";
            this.tbNote3.Size = new System.Drawing.Size(257, 22);
            this.tbNote3.TabIndex = 61;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(59, 341);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 22);
            this.label3.TabIndex = 60;
            this.label3.Text = "Note 3";
            // 
            // tbNote2
            // 
            this.tbNote2.Location = new System.Drawing.Point(237, 304);
            this.tbNote2.Name = "tbNote2";
            this.tbNote2.Size = new System.Drawing.Size(257, 22);
            this.tbNote2.TabIndex = 59;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(59, 304);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 22);
            this.label2.TabIndex = 58;
            this.label2.Text = "Note 2";
            // 
            // tbNote1
            // 
            this.tbNote1.Location = new System.Drawing.Point(237, 269);
            this.tbNote1.Name = "tbNote1";
            this.tbNote1.Size = new System.Drawing.Size(257, 22);
            this.tbNote1.TabIndex = 57;
            // 
            // note1
            // 
            this.note1.AutoSize = true;
            this.note1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.note1.Location = new System.Drawing.Point(59, 269);
            this.note1.Name = "note1";
            this.note1.Size = new System.Drawing.Size(63, 22);
            this.note1.TabIndex = 56;
            this.note1.Text = "Note 1";
            // 
            // Update_grade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(744, 596);
            this.Controls.Add(this.tbNote3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tbNote2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbNote1);
            this.Controls.Add(this.note1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.tbidcours);
            this.Controls.Add(this.nom_etudiant);
            this.Controls.Add(this.tbidetudiant);
            this.Controls.Add(this.id_étudiant);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Name = "Update_grade";
            this.Text = "Update_grade";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tbidcours;
        private System.Windows.Forms.Label nom_etudiant;
        private System.Windows.Forms.TextBox tbidetudiant;
        private System.Windows.Forms.Label id_étudiant;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox tbNote3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbNote2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbNote1;
        private System.Windows.Forms.Label note1;
    }
}