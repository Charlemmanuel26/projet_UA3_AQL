﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_UA3_forms
{
    public partial class Student : Form
    {

        private Create_Student createStudentsForm;
        public class StudentInfo
        {
            public string Id_étudiant { get; set; }
            public string Nom { get; set; }
            public string Prénom { get; set; }
        }


        public Student()
        {
            InitializeComponent();
            createStudentsForm = new Create_Student();
            createStudentsForm.StudentAdded += CreateStudentsForm_StudentAdded;
        }

        private void CreateStudentsForm_StudentAdded(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }

        private void Create_Students_StudentAdded(object sender, EventArgs e)
        {
            
            RefreshDataGridView();
        }      


        private void Student_Load(object sender, EventArgs e)
        {
            LoadStudentFiles();
        }

        private void create_student(object sender, EventArgs e)
        {
            using (Create_Student crs = new Create_Student())
            {                
                createStudentsForm.ShowDialog();
            }
        }




        private void update_students(object sender, EventArgs e)
        {
            using (Update_student upstudent = new Update_student())
            {
                upstudent.ShowDialog();
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LoadStudentFiles()
        {
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Étudiants";
            DirectoryInfo directory = new DirectoryInfo(directoryPath);
            List<StudentInfo> studentInfos = new List<StudentInfo>();

            foreach (FileInfo file in directory.GetFiles("*.txt"))
            {
                string[] parts = File.ReadAllText(file.FullName).Split(',');

                // Vérifier que le fichier contient au moins 3 parties
                if (parts.Length >= 3)
                {
                    string id_étudiant = parts[0].Trim();
                    string nom = parts[1].Trim();
                    string prénom = parts[2].Trim();

                    studentInfos.Add(new StudentInfo { Id_étudiant = id_étudiant, Nom = nom, Prénom = prénom });
                }
            }

            dataGridView1.DataSource = studentInfos;
        }

        public void RefreshDataGridView()
        {
            LoadStudentFiles();
        }
    }
}
