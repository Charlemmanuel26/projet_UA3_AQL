﻿using Project_UA3_forms.Create;
using Project_UA3_forms.Update;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Project_UA3_forms.Student;

namespace Project_UA3_forms.Classes
{
    public partial class Grade : Form
    {

        private Add_grade addgradeForm;
        public class GradeInfo
        {
            public string Id_Étudiant { get; set; }
            public string Id_Cours { get; set; }
            public string Note_1 { get; set; }
            public string Note_2 { get; set; }
            public string Note_3 { get; set; }
            public string Note_Final { get; internal set; }
        }
        public Grade()
        {
            InitializeComponent();
            addgradeForm = new Add_grade();
            addgradeForm.GradeAdded += AddgradeForm_GradeAdded;
            LoadGradeFiles();
        }

        private void AddgradeForm_GradeAdded(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }

        private void Add_Grade_GradeAdded(object sender, EventArgs e)
        {

            RefreshDataGridView();
        }

        private void Grade_Load(object sender, EventArgs e)
        {
            LoadGradeFiles();
        }

        private void Add_grade(object sender, EventArgs e)
        {
            using (Add_grade addgrade = new Add_grade())
            {
                addgradeForm.ShowDialog();
            }
        }

        private void Update_Grade(object sender, EventArgs e)
        {
            using (Update_grade updategrade = new Update_grade())
            {
                updategrade.ShowDialog();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LoadGradeFiles()
        {
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Notes";
            DirectoryInfo directory = new DirectoryInfo(directoryPath);
            List<GradeInfo> gradeInfos = new List<GradeInfo>();

            foreach (FileInfo file in directory.GetFiles("*.txt"))
            {
                string[] parts = File.ReadAllText(file.FullName).Split(',');


                if (parts.Length >= 5)
                {
                    string id_étudiant = parts[0].Trim();
                    string id_cours = parts[1].Trim();
                    string Note1 = parts[2].Trim();
                    string Note2 = parts[3].Trim();
                    string Note3 = parts[4].Trim();

                    gradeInfos.Add(new GradeInfo { Id_Étudiant = id_étudiant, Id_Cours = id_cours, Note_1 = Note1, Note_2 = Note2, Note_3 = Note3 });
                }
            }

            dataGridView1.DataSource = gradeInfos;
        }

        public void RefreshDataGridView()
        {
            LoadGradeFiles();
        }

        private void CalculNoteFinal(object sender, EventArgs e)
        {
            string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Notes";
            DirectoryInfo directory = new DirectoryInfo(directoryPath);

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.DataBoundItem != null)
                {
                    GradeInfo grade = (GradeInfo)row.DataBoundItem;

                    if (!string.IsNullOrEmpty(grade.Note_1) && !string.IsNullOrEmpty(grade.Note_2) && !string.IsNullOrEmpty(grade.Note_3))
                    {
                        double note1 = double.Parse(grade.Note_1);
                        double note2 = double.Parse(grade.Note_2);
                        double note3 = double.Parse(grade.Note_3);

                        double somme = note1 + note2 + note3;
                        grade.Note_Final = somme.ToString();

                        // Trouver le fichier correspondant à cet étudiant
                        string filePath = Path.Combine(directory.FullName, $"{grade.Id_Étudiant}.txt");

                        // Vérifier si le fichier existe avant de le modifier
                        if (File.Exists(filePath))
                        {
                            // Modifier le fichier pour inclure la note finale
                            string[] lines = File.ReadAllLines(filePath);
                            lines[4] = $"Note3: {grade.Note_3}, Note_Final: {grade.Note_Final}";
                            File.WriteAllLines(filePath, lines);
                        }
                        else
                        {
                            // Gérer le cas où le fichier n'existe pas
                            // Par exemple, vous pourriez créer un nouveau fichier avec les données
                        }
                    }
                }
            }

            dataGridView1.Refresh();
        }
    }
}

