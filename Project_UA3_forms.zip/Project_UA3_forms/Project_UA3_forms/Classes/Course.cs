﻿using Project_UA3_forms.Update;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Project_UA3_forms.Student;

namespace Project_UA3_forms
{
    public partial class Course : Form
    {
        private Create_course createCourseForm;
        public class CoursInfos
        {
            public string Id_Cours { get; set; }
            public string Code { get; set; }
            public string Titre { get; set; }
        }
        public Course()
        {
            InitializeComponent();
            createCourseForm = new Create_course();
            createCourseForm.CourseAdded += CreateCourseForm_CourseAdded;

            LoadCoursFiles();
        }


        private void CreateCourseForm_CourseAdded(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }

        private void Create_Course_CourseAdded(object sender, EventArgs e)
        {

            RefreshDataGridView();
        }



        private void Cours_Load(object sender, EventArgs e)
        {
            LoadCoursFiles();
        }

        private void Create_course_button(object sender, EventArgs e)
        {
            using (Create_course cc = new Create_course())
            {
                createCourseForm.ShowDialog();
            }
        }

        private void Update_course_button(object sender, EventArgs e)
        {
            using (Update_course upc = new Update_course())
            {
                upc.ShowDialog();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
          
        private void LoadCoursFiles()
        {
                string directoryPath = @"C:\Users\charl\OneDrive\Bureau\Documents\Assurance qualité\Project_UA3_forms\Project_UA3_forms\bin\Debug\Cours";
                DirectoryInfo directory = new DirectoryInfo(directoryPath);
                List<CoursInfos> CoursInfos = new List<CoursInfos>();

                foreach (FileInfo file in directory.GetFiles("*.txt"))
                {
                    string[] parts = File.ReadAllText(file.FullName).Split(',');

                    // Vérifier que le fichier contient au moins 3 parties
                    if (parts.Length >= 3)
                    {
                        string id_cours = parts[0].Trim();
                        string code = parts[1].Trim();
                        string titre = parts[2].Trim();

                        CoursInfos.Add(new CoursInfos { Id_Cours = id_cours, Code = code, Titre = titre });
                    }
                }

                dataGridView1.DataSource = CoursInfos;
            }

            public void RefreshDataGridView()
            {
                LoadCoursFiles();
            }

        }
    }
